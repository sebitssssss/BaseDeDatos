using System;
using MySqlConnector;
using CodeBreaker.Models;

namespace CodeBreaker.Data
{
    // Inicio clase DatabaseService
    public class DatabaseService
    {
        public const uint ConnectionTimeoutSeconds = 3;

        private readonly GameConfig config;

        public bool WasChecked { get; private set; }
        public bool IsConnected { get; private set; }
        public string ErrorDetail { get; private set; }

        // Inicio constructor DatabaseService
        public DatabaseService(GameConfig config)
        {
            this.config = config;
            ErrorDetail = "";
        }
        // Fin constructor DatabaseService

        // Inicio propiedad StatusText
        public string StatusText
        {
            get
            {
                if (!WasChecked)
                {
                    return "verificando...";
                }
                return IsConnected ? "conectada" : "sin conexión";
            }
        }
        // Fin propiedad StatusText

        // Inicio método BuildConnectionString
        public string BuildConnectionString()
        {
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = config.DbServer;
            builder.Port = (uint)config.DbPort;
            builder.Database = config.DbName;
            builder.UserID = config.DbUser;
            builder.Password = config.DbPassword;
            builder.ConnectionTimeout = ConnectionTimeoutSeconds;
            return builder.ConnectionString;
        }
        // Fin método BuildConnectionString

        // Inicio método TestConnection
        public bool TestConnection()
        {
            WasChecked = true;
            try
            {
                using (MySqlConnection connection = new MySqlConnection(BuildConnectionString()))
                {
                    connection.Open();
                    IsConnected = true;
                    ErrorDetail = "";
                }
            }
            catch (MySqlException ex)
            {
                IsConnected = false;
                ErrorDetail = ex.Message;
            }
            catch (Exception ex)
            {
                IsConnected = false;
                ErrorDetail = ex.Message;
            }
            return IsConnected;
        }
        // Fin método TestConnection
    }
    // Fin clase DatabaseService
}
