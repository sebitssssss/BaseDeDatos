using System;
using System.Globalization;
using System.IO;
using System.Xml;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace CodeBreaker.Data
{
    // Inicio clase SpriteAtlas
    public class SpriteAtlas
    {
        public const int NotFound = -1;
        public const int MaxTextures = 32;
        public const int MaxSprites = 4096;

        private readonly Texture2D[] textures = new Texture2D[MaxTextures];
        private readonly string[] textureFileNames = new string[MaxTextures];
        private int textureCount = 0;

        private readonly string[] names = new string[MaxSprites];
        private readonly Rectangle[] sources = new Rectangle[MaxSprites];
        private readonly int[] textureIndexes = new int[MaxSprites];
        private int spriteCount = 0;

        public string Warning { get; private set; }

        // Inicio constructor SpriteAtlas
        public SpriteAtlas()
        {
            Warning = "";
        }
        // Fin constructor SpriteAtlas

        // Inicio propiedad SpriteCount
        public int SpriteCount
        {
            get { return spriteCount; }
        }
        // Fin propiedad SpriteCount

        // Inicio método LoadFolder
        public void LoadFolder(GraphicsDevice device, string folder)
        {
            string[] xmlFiles;
            string[] pngFiles;
            try
            {
                if (!Directory.Exists(folder))
                {
                    return;
                }
                xmlFiles = Directory.GetFiles(folder, "*.xml");
                pngFiles = Directory.GetFiles(folder, "*.png");
            }
            catch (Exception ex)
            {
                AddWarning("No se pudo leer Content/Sprites (" + ex.Message + ").");
                return;
            }

            for (int i = 0; i < xmlFiles.Length; i++)
            {
                if (textureCount == MaxTextures)
                {
                    AddWarning("Hay más de " + MaxTextures + " imágenes en Content/Sprites: se ignoran las demás.");
                    return;
                }
                try
                {
                    LoadSheet(device, xmlFiles[i]);
                }
                catch (Exception ex)
                {
                    AddWarning("No se pudo cargar " + Path.GetFileName(xmlFiles[i]) + " (" + ex.Message + ").");
                }
            }

            for (int i = 0; i < pngFiles.Length; i++)
            {
                string fileName = Path.GetFileName(pngFiles[i]);
                if (IsLoadedImage(fileName))
                {
                    continue;
                }
                if (textureCount == MaxTextures)
                {
                    AddWarning("Hay más de " + MaxTextures + " imágenes en Content/Sprites: se ignoran las demás.");
                    return;
                }
                try
                {
                    LoadSingleImage(device, pngFiles[i]);
                }
                catch (Exception ex)
                {
                    AddWarning("No se pudo cargar " + fileName + " (" + ex.Message + ").");
                }
            }
        }
        // Fin método LoadFolder

        // Inicio método IsLoadedImage
        private bool IsLoadedImage(string fileName)
        {
            for (int i = 0; i < textureCount; i++)
            {
                if (string.Equals(textureFileNames[i], fileName, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }
        // Fin método IsLoadedImage

        // Inicio método LoadSheet
        private void LoadSheet(GraphicsDevice device, string xmlPath)
        {
            int firstSprite = spriteCount;
            try
            {
                string imageName = ReadXml(xmlPath);
                if (spriteCount == firstSprite)
                {
                    throw new InvalidDataException("el XML no tiene etiquetas SubTexture");
                }

                string imagePath = Path.Combine(Path.GetDirectoryName(xmlPath), imageName);
                textures[textureCount] = Texture2D.FromFile(device, imagePath, DefaultColorProcessors.PremultiplyAlpha);
                textureFileNames[textureCount] = Path.GetFileName(imageName);
                textureCount++;
            }
            catch (Exception)
            {
                spriteCount = firstSprite;
                throw;
            }
        }
        // Fin método LoadSheet

        // Inicio método LoadSingleImage
        private void LoadSingleImage(GraphicsDevice device, string pngPath)
        {
            if (spriteCount == MaxSprites)
            {
                AddWarning("Se llegó al máximo de " + MaxSprites + " sprites: se ignoran los demás.");
                return;
            }

            Texture2D texture = Texture2D.FromFile(device, pngPath, DefaultColorProcessors.PremultiplyAlpha);
            textures[textureCount] = texture;
            textureFileNames[textureCount] = Path.GetFileName(pngPath);

            names[spriteCount] = Path.GetFileName(pngPath);
            sources[spriteCount] = new Rectangle(0, 0, texture.Width, texture.Height);
            textureIndexes[spriteCount] = textureCount;
            spriteCount++;
            textureCount++;
        }
        // Fin método LoadSingleImage

        // Inicio método ReadXml
        private string ReadXml(string xmlPath)
        {
            string imageName = "";
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.DtdProcessing = DtdProcessing.Ignore;

            using (XmlReader reader = XmlReader.Create(xmlPath, settings))
            {
                while (reader.Read())
                {
                    if (reader.NodeType != XmlNodeType.Element)
                    {
                        continue;
                    }

                    if (reader.Name == "TextureAtlas")
                    {
                        imageName = reader.GetAttribute("imagePath");
                    }
                    else if (reader.Name == "SubTexture")
                    {
                        AddSprite(reader);
                    }
                }
            }

            if (string.IsNullOrEmpty(imageName))
            {
                throw new InvalidDataException("falta imagePath en <TextureAtlas>");
            }
            return imageName;
        }
        // Fin método ReadXml

        // Inicio método AddSprite
        private void AddSprite(XmlReader reader)
        {
            if (spriteCount == MaxSprites)
            {
                AddWarning("Se llegó al máximo de " + MaxSprites + " sprites: se ignoran los demás.");
                return;
            }

            string name = reader.GetAttribute("name");
            int x = ReadInt(reader, "x");
            int y = ReadInt(reader, "y");
            int width = ReadInt(reader, "width");
            int height = ReadInt(reader, "height");
            if (name == null || width <= 0 || height <= 0)
            {
                return;
            }

            names[spriteCount] = name;
            sources[spriteCount] = new Rectangle(x, y, width, height);
            textureIndexes[spriteCount] = textureCount;
            spriteCount++;
        }
        // Fin método AddSprite

        // Inicio método ReadInt
        private static int ReadInt(XmlReader reader, string attribute)
        {
            string text = reader.GetAttribute(attribute);
            if (text == null)
            {
                throw new InvalidDataException("a una SubTexture le falta '" + attribute + "'");
            }
            return int.Parse(text, CultureInfo.InvariantCulture);
        }
        // Fin método ReadInt

        // Inicio método Find
        public int Find(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                return NotFound;
            }
            for (int i = 0; i < spriteCount; i++)
            {
                if (string.Equals(names[i], text, StringComparison.OrdinalIgnoreCase))
                {
                    return i;
                }
            }
            for (int i = 0; i < spriteCount; i++)
            {
                if (names[i].IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return i;
                }
            }
            return NotFound;
        }
        // Fin método Find

        // Inicio método Draw
        public void Draw(SpriteBatch spriteBatch, int spriteIndex, Rectangle area)
        {
            if (spriteIndex < 0 || spriteIndex >= spriteCount)
            {
                return;
            }

            Rectangle source = sources[spriteIndex];
            float scaleX = (float)area.Width / source.Width;
            float scaleY = (float)area.Height / source.Height;
            float scale = scaleX < scaleY ? scaleX : scaleY;

            int width = (int)(source.Width * scale);
            int height = (int)(source.Height * scale);
            Rectangle destination = new Rectangle(
                area.X + (area.Width - width) / 2,
                area.Y + (area.Height - height) / 2,
                width,
                height);

            spriteBatch.Draw(textures[textureIndexes[spriteIndex]], destination, source, Color.White);
        }
        // Fin método Draw

        // Inicio método AddWarning
        private void AddWarning(string text)
        {
            Warning = Warning.Length == 0 ? text : Warning + " " + text;
        }
        // Fin método AddWarning
    }
    // Fin clase SpriteAtlas
}
