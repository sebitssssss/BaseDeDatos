using System;
using System.IO;
using CodeBreaker.Logic;
using CodeBreaker.Models;

namespace CodeBreaker.Data
{
    // Inicio clase ScoreFile
    public class ScoreFile
    {
        public const string FileName = "puntajes.dat";
        public const int MaxRecords = 100;
        private const int MaxNameLength = 50;

        private readonly string filePath;
        private readonly ScoreRecord[] records = new ScoreRecord[MaxRecords];
        private int count = 0;

        public string Warning { get; private set; }

        // Inicio propiedad Count
        public int Count
        {
            get { return count; }
        }
        // Fin propiedad Count

        // Inicio constructor ScoreFile
        public ScoreFile(string folder)
        {
            filePath = Path.Combine(folder, FileName);
            Warning = "";
        }
        // Fin constructor ScoreFile

        // Inicio método GetAt
        public ScoreRecord GetAt(int index)
        {
            if (index < 0 || index >= count)
            {
                return null;
            }
            return records[index];
        }
        // Fin método GetAt

        // Inicio método Load
        public void Load()
        {
            count = 0;
            Warning = "";

            if (!File.Exists(filePath))
            {
                return;
            }

            try
            {
                using (BinaryReader reader = new BinaryReader(File.Open(filePath, FileMode.Open, FileAccess.Read)))
                {
                    int total = reader.ReadInt32();
                    if (total < 0 || total > MaxRecords)
                    {
                        throw new InvalidDataException("la cantidad de registros (" + total + ") no es válida");
                    }

                    for (int i = 0; i < total; i++)
                    {
                        string name = reader.ReadString();
                        int score = reader.ReadInt32();
                        int livesLeft = reader.ReadInt32();
                        int seconds = reader.ReadInt32();
                        long ticks = reader.ReadInt64();

                        bool invalid = name.Length > MaxNameLength || score < 0 || livesLeft < 0 || seconds < 0
                            || ticks < DateTime.MinValue.Ticks || ticks > DateTime.MaxValue.Ticks;
                        if (invalid)
                        {
                            throw new InvalidDataException("el registro " + (i + 1) + " tiene datos inválidos");
                        }

                        records[i] = new ScoreRecord(name, score, livesLeft, seconds, new DateTime(ticks));
                    }

                    count = total;
                }
            }
            catch (Exception ex)
            {
                count = 0;
                Warning = "puntajes.dat está dañado (" + ex.Message + "): el ranking empieza vacío y se reemplaza al guardar.";
            }
        }
        // Fin método Load

        // Inicio método Save
        public bool Save()
        {
            try
            {
                using (BinaryWriter writer = new BinaryWriter(File.Open(filePath, FileMode.Create, FileAccess.Write)))
                {
                    writer.Write(count);
                    for (int i = 0; i < count; i++)
                    {
                        writer.Write(records[i].PlayerName);
                        writer.Write(records[i].Score);
                        writer.Write(records[i].LivesLeft);
                        writer.Write(records[i].Seconds);
                        writer.Write(records[i].Date.Ticks);
                    }
                }
                Warning = "";
                return true;
            }
            catch (Exception ex)
            {
                Warning = "No se pudo guardar puntajes.dat (" + ex.Message + ").";
                return false;
            }
        }
        // Fin método Save

        // Inicio método AddAndSave
        public string AddAndSave(ScoreRecord record)
        {
            if (count < MaxRecords)
            {
                records[count] = record;
                count++;
            }
            else
            {
                SortRanking();
                if (!BubbleSorter.IsBetter(record, records[count - 1]))
                {
                    return "";
                }
                records[count - 1] = record;
            }

            if (Save())
            {
                return "";
            }
            return Warning;
        }
        // Fin método AddAndSave

        // Inicio método SortRanking
        public void SortRanking()
        {
            BubbleSorter.Sort(records, count);
        }
        // Fin método SortRanking
    }
    // Fin clase ScoreFile
}
