namespace CodeBreaker
{
    // Inicio enum GameState
    public enum GameState
    {
        Menu,
        Playing,
        GameOver,
        Ranking
    }
    // Fin enum GameState
}
