namespace CodeBreaker.Models
{
    // Inicio clase Attempt
    public class Attempt
    {
        public int Number { get; private set; }
        public PegColor[] Pegs { get; private set; }
        public PegResult[] Results { get; private set; }
        public int ExactCount { get; private set; }
        public int PresentCount { get; private set; }

        // Inicio constructor Attempt
        public Attempt(int number, PegColor[] guess, PegResult[] results, int length)
        {
            Number = number;
            Pegs = new PegColor[length];
            Results = new PegResult[length];
            ExactCount = 0;
            PresentCount = 0;
            for (int i = 0; i < length; i++)
            {
                Pegs[i] = guess[i];
                Results[i] = results[i];
                if (results[i] == PegResult.Exact)
                {
                    ExactCount++;
                }
                else if (results[i] == PegResult.Present)
                {
                    PresentCount++;
                }
            }
        }
        // Fin constructor Attempt
    }
    // Fin clase Attempt
}
