namespace CodeBreaker.Models
{
    // Inicio enum PegResult
    public enum PegResult
    {
        Absent = 0,
        Present = 1,
        Exact = 2
    }
    // Fin enum PegResult
}
