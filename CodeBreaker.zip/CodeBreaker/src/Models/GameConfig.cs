namespace CodeBreaker.Models
{
    // Inicio clase GameConfig
    public class GameConfig
    {
        public const string DefaultDbServer = "localhost";
        public const int DefaultDbPort = 3306;
        public const string DefaultDbName = "codigo_secreto_db";
        public const string DefaultDbUser = "root";
        public const string DefaultDbPassword = "";

        public const int DefaultCodeLength = 4;
        public const int DefaultLives = 8;
        public const int DefaultPointsPerLife = 100;
        public const int DefaultTimeBonusMax = 300;

        public const int MinCodeLength = 2;
        public const int MaxCodeLength = 6;
        public const int MinLives = 1;
        public const int MaxLives = 12;
        public const int MinPort = 1;
        public const int MaxPort = 65535;

        public static readonly string[] DefaultColorSprites = { "rojo.png", "azul.png", "verde.png", "amarillo.png", "naranja.png", "morado.png" };
        public const string DefaultFrameExactSprite = "aro_verde.png";
        public const string DefaultFramePresentSprite = "aro_amarillo.png";
        public const string DefaultFrameAbsentSprite = "aro_rojo.png";
        public const string DefaultCursorSprite = "";
        public const string DefaultEmptySprite = "";

        public string DbServer { get; set; }
        public int DbPort { get; set; }
        public string DbName { get; set; }
        public string DbUser { get; set; }
        public string DbPassword { get; set; }

        public int CodeLength { get; set; }
        public int Lives { get; set; }
        public int PointsPerLife { get; set; }
        public int TimeBonusMax { get; set; }
        public bool DebugShowSecret { get; set; }

        public string[] ColorSprites { get; private set; }
        public string FrameExactSprite { get; set; }
        public string FramePresentSprite { get; set; }
        public string FrameAbsentSprite { get; set; }
        public string CursorSprite { get; set; }
        public string EmptySprite { get; set; }

        // Inicio constructor GameConfig
        public GameConfig()
        {
            DbServer = DefaultDbServer;
            DbPort = DefaultDbPort;
            DbName = DefaultDbName;
            DbUser = DefaultDbUser;
            DbPassword = DefaultDbPassword;

            CodeLength = DefaultCodeLength;
            Lives = DefaultLives;
            PointsPerLife = DefaultPointsPerLife;
            TimeBonusMax = DefaultTimeBonusMax;
            DebugShowSecret = false;

            ColorSprites = new string[Palette.ColorCount];
            for (int i = 0; i < Palette.ColorCount; i++)
            {
                ColorSprites[i] = DefaultColorSprites[i];
            }
            FrameExactSprite = DefaultFrameExactSprite;
            FramePresentSprite = DefaultFramePresentSprite;
            FrameAbsentSprite = DefaultFrameAbsentSprite;
            CursorSprite = DefaultCursorSprite;
            EmptySprite = DefaultEmptySprite;
        }
        // Fin constructor GameConfig
    }
    // Fin clase GameConfig
}
