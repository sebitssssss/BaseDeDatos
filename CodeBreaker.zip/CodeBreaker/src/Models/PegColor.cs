namespace CodeBreaker.Models
{
    // Inicio enum PegColor
    public enum PegColor
    {
        Red = 0,
        Blue = 1,
        Green = 2,
        Yellow = 3,
        Orange = 4,
        Purple = 5
    }
    // Fin enum PegColor
}
