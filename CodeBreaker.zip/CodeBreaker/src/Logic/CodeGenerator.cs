using System;
using CodeBreaker.Models;

namespace CodeBreaker.Logic
{
    // Inicio clase CodeGenerator
    public class CodeGenerator
    {
        private readonly Random random = new Random();

        // Inicio método Generate
        public PegColor[] Generate(int length)
        {
            PegColor[] code = new PegColor[length];
            for (int i = 0; i < length; i++)
            {
                code[i] = (PegColor)random.Next(Palette.ColorCount);
            }
            return code;
        }
        // Fin método Generate
    }
    // Fin clase CodeGenerator
}
