namespace CodeBreaker.Logic
{
    // Inicio clase ScoreService
    public class ScoreService
    {
        private readonly int pointsPerLife;
        private readonly int timeBonusMax;

        // Inicio constructor ScoreService
        public ScoreService(int pointsPerLife, int timeBonusMax)
        {
            this.pointsPerLife = pointsPerLife;
            this.timeBonusMax = timeBonusMax;
        }
        // Fin constructor ScoreService

        // Inicio método Calculate
        public int Calculate(int livesLeft, int secondsPlayed, bool won)
        {
            if (!won)
            {
                return 0;
            }
            int timeBonus = timeBonusMax - secondsPlayed;
            if (timeBonus < 0)
            {
                timeBonus = 0;
            }
            return livesLeft * pointsPerLife + timeBonus;
        }
        // Fin método Calculate
    }
    // Fin clase ScoreService
}
