using CodeBreaker.Models;

namespace CodeBreaker.Logic
{
    // Inicio clase GameSession
    public class GameSession
    {
        private readonly CodeGenerator codeGenerator;
        private readonly ScoreService scoreService;

        private PegColor[] secretCode;
        private readonly PegColor[] currentGuess;
        private int currentCount;
        private double elapsedSeconds;

        public string PlayerName { get; private set; }
        public int CodeLength { get; private set; }
        public int MaxLives { get; private set; }
        public int Lives { get; private set; }
        public bool IsFinished { get; private set; }
        public bool IsWon { get; private set; }
        public int FinalScore { get; private set; }
        public CircularQueue History { get; private set; }
        public string Warning { get; private set; }

        // Inicio constructor GameSession
        public GameSession(GameConfig config, CodeGenerator codeGenerator, ScoreService scoreService)
        {
            this.codeGenerator = codeGenerator;
            this.scoreService = scoreService;
            CodeLength = config.CodeLength;
            MaxLives = config.Lives;
            currentGuess = new PegColor[CodeLength];
            secretCode = new PegColor[CodeLength];
            History = new CircularQueue(MaxLives);
            PlayerName = "";
            Warning = "";
        }
        // Fin constructor GameSession

        // Inicio método StartNew
        public void StartNew(string playerName)
        {
            PlayerName = playerName;
            secretCode = codeGenerator.Generate(CodeLength);
            History.Clear();
            currentCount = 0;
            Lives = MaxLives;
            elapsedSeconds = 0;
            IsFinished = false;
            IsWon = false;
            FinalScore = 0;
            Warning = "";
        }
        // Fin método StartNew

        // Inicio propiedad CurrentCount
        public int CurrentCount
        {
            get { return currentCount; }
        }
        // Fin propiedad CurrentCount

        // Inicio propiedad SecondsPlayed
        public int SecondsPlayed
        {
            get { return (int)elapsedSeconds; }
        }
        // Fin propiedad SecondsPlayed

        // Inicio método GetGuessAt
        public PegColor GetGuessAt(int position)
        {
            return currentGuess[position];
        }
        // Fin método GetGuessAt

        // Inicio método GetSecretAt
        public PegColor GetSecretAt(int position)
        {
            return secretCode[position];
        }
        // Fin método GetSecretAt

        // Inicio método IsGuessComplete
        public bool IsGuessComplete()
        {
            return currentCount == CodeLength;
        }
        // Fin método IsGuessComplete

        // Inicio método AddTime
        public void AddTime(double seconds)
        {
            if (!IsFinished)
            {
                elapsedSeconds += seconds;
            }
        }
        // Fin método AddTime

        // Inicio método PotentialScore
        public int PotentialScore()
        {
            return scoreService.Calculate(Lives, SecondsPlayed, true);
        }
        // Fin método PotentialScore

        // Inicio método PlaceColor
        public bool PlaceColor(int position, PegColor color)
        {
            if (IsFinished || position < 0)
            {
                return false;
            }
            if (position < currentCount)
            {
                currentGuess[position] = color;
                return true;
            }
            if (position == currentCount && currentCount < CodeLength)
            {
                currentGuess[currentCount] = color;
                currentCount++;
                return true;
            }
            return false;
        }
        // Fin método PlaceColor

        // Inicio método RemoveLast
        public bool RemoveLast()
        {
            if (currentCount == 0)
            {
                return false;
            }
            currentCount--;
            return true;
        }
        // Fin método RemoveLast

        // Inicio método SubmitGuess
        public Attempt SubmitGuess()
        {
            if (IsFinished || !IsGuessComplete())
            {
                return null;
            }

            PegResult[] results = FeedbackEvaluator.Evaluate(secretCode, currentGuess, CodeLength);
            Attempt attempt = new Attempt(History.Count() + 1, currentGuess, results, CodeLength);
            if (!History.Enqueue(attempt))
            {
                Warning = "El historial está lleno: este intento no se guardó en la cola.";
            }
            currentCount = 0;

            if (attempt.ExactCount == CodeLength)
            {
                IsWon = true;
                IsFinished = true;
                FinalScore = scoreService.Calculate(Lives, SecondsPlayed, true);
            }
            else
            {
                Lives--;
                if (Lives <= 0)
                {
                    Lives = 0;
                    IsWon = false;
                    IsFinished = true;
                    FinalScore = scoreService.Calculate(Lives, SecondsPlayed, false);
                }
            }
            return attempt;
        }
        // Fin método SubmitGuess
    }
    // Fin clase GameSession
}
