using CodeBreaker.Models;

namespace CodeBreaker.Logic
{
    // Inicio clase CircularQueue
    public class CircularQueue
    {
        private const int NoRear = -1;

        private readonly Attempt[] items;
        private int front;
        private int rear;
        private int count;

        // Inicio constructor CircularQueue
        public CircularQueue(int capacity)
        {
            if (capacity < 1)
            {
                capacity = 1;
            }
            items = new Attempt[capacity];
            Clear();
        }
        // Fin constructor CircularQueue

        // Inicio método Capacity
        public int Capacity()
        {
            return items.Length;
        }
        // Fin método Capacity

        // Inicio método Count
        public int Count()
        {
            return count;
        }
        // Fin método Count

        // Inicio método IsEmpty
        public bool IsEmpty()
        {
            return count == 0;
        }
        // Fin método IsEmpty

        // Inicio método IsFull
        public bool IsFull()
        {
            return count == items.Length;
        }
        // Fin método IsFull

        // Inicio método Enqueue
        public bool Enqueue(Attempt item)
        {
            if (IsFull())
            {
                return false;
            }
            rear = (rear + 1) % items.Length;
            items[rear] = item;
            count++;
            return true;
        }
        // Fin método Enqueue

        // Inicio método Dequeue
        public bool Dequeue(out Attempt item)
        {
            if (IsEmpty())
            {
                item = null;
                return false;
            }
            item = items[front];
            items[front] = null;
            front = (front + 1) % items.Length;
            count--;
            return true;
        }
        // Fin método Dequeue

        // Inicio método Peek
        public bool Peek(out Attempt item)
        {
            if (IsEmpty())
            {
                item = null;
                return false;
            }
            item = items[front];
            return true;
        }
        // Fin método Peek

        // Inicio método GetAt
        public Attempt GetAt(int i)
        {
            if (i < 0 || i >= count)
            {
                return null;
            }
            return items[(front + i) % items.Length];
        }
        // Fin método GetAt

        // Inicio método Clear
        public void Clear()
        {
            for (int i = 0; i < items.Length; i++)
            {
                items[i] = null;
            }
            front = 0;
            rear = NoRear;
            count = 0;
        }
        // Fin método Clear
    }
    // Fin clase CircularQueue
}
