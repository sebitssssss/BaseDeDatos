using CodeBreaker.Models;

namespace CodeBreaker.Logic
{
    // Inicio clase BubbleSorter
    public static class BubbleSorter
    {
        // Inicio método Sort
        public static void Sort(ScoreRecord[] records, int count)
        {
            for (int pass = 0; pass < count - 1; pass++)
            {
                bool swapped = false;

                for (int i = 0; i < count - 1 - pass; i++)
                {
                    if (IsBetter(records[i + 1], records[i]))
                    {
                        ScoreRecord temp = records[i];
                        records[i] = records[i + 1];
                        records[i + 1] = temp;
                        swapped = true;
                    }
                }

                if (!swapped)
                {
                    break;
                }
            }
        }
        // Fin método Sort

        // Inicio método IsBetter
        public static bool IsBetter(ScoreRecord a, ScoreRecord b)
        {
            if (a.Score != b.Score)
            {
                return a.Score > b.Score;
            }
            return a.Seconds < b.Seconds;
        }
        // Fin método IsBetter
    }
    // Fin clase BubbleSorter
}
