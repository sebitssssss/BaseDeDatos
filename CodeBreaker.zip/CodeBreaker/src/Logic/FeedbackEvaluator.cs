using CodeBreaker.Models;

namespace CodeBreaker.Logic
{
    // Inicio clase FeedbackEvaluator
    public static class FeedbackEvaluator
    {
        // Inicio método Evaluate
        public static PegResult[] Evaluate(PegColor[] secret, PegColor[] guess, int length)
        {
            PegResult[] results = new PegResult[length];
            int[] unusedSecretColors = new int[Palette.ColorCount];

            for (int i = 0; i < length; i++)
            {
                if (guess[i] == secret[i])
                {
                    results[i] = PegResult.Exact;
                }
                else
                {
                    results[i] = PegResult.Absent;
                    unusedSecretColors[(int)secret[i]]++;
                }
            }

            for (int i = 0; i < length; i++)
            {
                if (results[i] == PegResult.Exact)
                {
                    continue;
                }
                int color = (int)guess[i];
                if (unusedSecretColors[color] > 0)
                {
                    results[i] = PegResult.Present;
                    unusedSecretColors[color]--;
                }
            }

            return results;
        }
        // Fin método Evaluate
    }
    // Fin clase FeedbackEvaluator
}
