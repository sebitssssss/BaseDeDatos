using System;

namespace CodeBreaker
{
    // Inicio clase Program
    public static class Program
    {
        // Inicio método Main
        [STAThread]
        public static void Main()
        {
            using (Game1 game = new Game1())
            {
                game.Run();
            }
        }
        // Fin método Main
    }
    // Fin clase Program
}
