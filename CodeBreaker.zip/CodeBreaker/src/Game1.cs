using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using CodeBreaker.Data;
using CodeBreaker.Logic;
using CodeBreaker.Models;
using CodeBreaker.Screens;

namespace CodeBreaker
{
    // Inicio clase Game1
    public class Game1 : Game
    {
        private const string SpritesFolder = "Sprites";

        private readonly GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        private GameState state = GameState.Menu;

        private ConfigManager configManager;
        private ScoreFile scoreFile;
        private DatabaseService database;
        private SpriteAtlas atlas;
        private Renderer renderer;
        private readonly InputHelper input = new InputHelper();

        private GameSession session;
        private MenuScreen menuScreen;
        private PlayingScreen playingScreen;
        private GameOverScreen gameOverScreen;
        private RankingScreen rankingScreen;

        private bool firstFrameDrawn = false;

        // Inicio constructor Game1
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = Renderer.ScreenWidth;
            graphics.PreferredBackBufferHeight = Renderer.ScreenHeight;
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            Window.Title = "Code Breaker";
        }
        // Fin constructor Game1

        // Inicio método Initialize
        protected override void Initialize()
        {
            string folder = AppContext.BaseDirectory;

            configManager = new ConfigManager(folder);
            configManager.Load();
            GameConfig config = configManager.Config;

            scoreFile = new ScoreFile(folder);
            scoreFile.Load();

            database = new DatabaseService(config);

            ScoreService scoreService = new ScoreService(config.PointsPerLife, config.TimeBonusMax);
            session = new GameSession(config, new CodeGenerator(), scoreService);

            menuScreen = new MenuScreen();
            playingScreen = new PlayingScreen(session, config.DebugShowSecret);
            gameOverScreen = new GameOverScreen();
            rankingScreen = new RankingScreen();

            Window.TextInput += OnTextInput;

            base.Initialize();
        }
        // Fin método Initialize

        // Inicio método LoadContent
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            SpriteFont titleFont = Content.Load<SpriteFont>("Fonts/Title");
            SpriteFont regularFont = Content.Load<SpriteFont>("Fonts/Regular");
            SpriteFont mediumFont = Content.Load<SpriteFont>("Fonts/Medium");
            SpriteFont smallFont = Content.Load<SpriteFont>("Fonts/Small");

            atlas = new SpriteAtlas();
            string spritesPath = Path.Combine(AppContext.BaseDirectory, Content.RootDirectory, SpritesFolder);
            atlas.LoadFolder(GraphicsDevice, spritesPath);

            renderer = new Renderer(spriteBatch, atlas, titleFont, regularFont, mediumFont, smallFont);
            renderer.ResolveSprites(configManager.Config);
        }
        // Fin método LoadContent

        // Inicio método OnTextInput
        private void OnTextInput(object sender, TextInputEventArgs e)
        {
            if (state == GameState.Menu)
            {
                menuScreen.OnCharacterTyped(e.Character);
            }
        }
        // Fin método OnTextInput

        // Inicio método Update
        protected override void Update(GameTime gameTime)
        {
            input.Update();

            if (firstFrameDrawn && !database.WasChecked)
            {
                database.TestConnection();
            }

            GameState next = state;
            switch (state)
            {
                case GameState.Menu:
                    next = menuScreen.Update(input, database);
                    break;
                case GameState.Playing:
                    next = playingScreen.Update(gameTime, input);
                    break;
                case GameState.GameOver:
                    next = gameOverScreen.Update(gameTime, input);
                    break;
                case GameState.Ranking:
                    next = rankingScreen.Update(input);
                    break;
            }

            if (menuScreen.ExitRequested)
            {
                Exit();
            }
            else
            {
                ChangeState(next);
            }

            base.Update(gameTime);
        }
        // Fin método Update

        // Inicio método ChangeState
        private void ChangeState(GameState next)
        {
            if (next == state)
            {
                return;
            }

            if (next == GameState.Playing)
            {
                playingScreen.StartNewGame(menuScreen.PlayerName);
            }
            else if (next == GameState.GameOver)
            {
                gameOverScreen.Show(session, SaveResult());
            }
            else if (next == GameState.Ranking)
            {
                scoreFile.SortRanking();
            }
            state = next;
        }
        // Fin método ChangeState

        // Inicio método SaveResult
        private string SaveResult()
        {
            if (!session.IsWon)
            {
                return "";
            }
            ScoreRecord record = new ScoreRecord(session.PlayerName, session.FinalScore, session.Lives, session.SecondsPlayed, DateTime.Now);
            return scoreFile.AddAndSave(record);
        }
        // Fin método SaveResult

        // Inicio método Draw
        protected override void Draw(GameTime gameTime)
        {
            bool isDefeat = state == GameState.GameOver && !session.IsWon;
            GraphicsDevice.Clear(isDefeat ? Renderer.DefeatBackgroundColor : Renderer.BackgroundColor);
            spriteBatch.Begin();

            switch (state)
            {
                case GameState.Menu:
                    menuScreen.Draw(renderer, database, GetWarnings());
                    break;
                case GameState.Playing:
                    playingScreen.Draw(renderer);
                    break;
                case GameState.GameOver:
                    gameOverScreen.Draw(renderer);
                    break;
                case GameState.Ranking:
                    rankingScreen.Draw(renderer, scoreFile);
                    break;
            }

            spriteBatch.End();
            firstFrameDrawn = true;
            base.Draw(gameTime);
        }
        // Fin método Draw

        // Inicio método GetWarnings
        private string GetWarnings()
        {
            string text = "";
            text = JoinWarning(text, configManager.Warning);
            text = JoinWarning(text, scoreFile.Warning);
            text = JoinWarning(text, atlas.Warning);
            text = JoinWarning(text, renderer.Warning);
            return text;
        }
        // Fin método GetWarnings

        // Inicio método JoinWarning
        private static string JoinWarning(string text, string warning)
        {
            if (warning.Length == 0)
            {
                return text;
            }
            return text.Length == 0 ? warning : text + " " + warning;
        }
        // Fin método JoinWarning
    }
    // Fin clase Game1
}
