using Microsoft.Xna.Framework.Input;

namespace CodeBreaker.Screens
{
    // Inicio clase InputHelper
    public class InputHelper
    {
        private KeyboardState previous;
        private KeyboardState current;

        // Inicio método Update
        public void Update()
        {
            previous = current;
            current = Keyboard.GetState();
        }
        // Fin método Update

        // Inicio método WasPressed
        public bool WasPressed(Keys key)
        {
            return current.IsKeyDown(key) && previous.IsKeyUp(key);
        }
        // Fin método WasPressed
    }
    // Fin clase InputHelper
}
