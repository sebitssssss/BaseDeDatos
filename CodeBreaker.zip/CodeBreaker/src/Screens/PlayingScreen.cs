using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using CodeBreaker.Logic;
using CodeBreaker.Models;

namespace CodeBreaker.Screens
{
    // Inicio clase PlayingScreen
    public class PlayingScreen
    {
        private const int TopBarY = 18;
        private const int LivesX = 40;
        private const int RightMargin = 40;

        private const float GreenRatio = 0.75f;
        private const float YellowRatio = 0.5f;

        private const int HistoryX = 40;
        private const int HistoryTitleY = 100;
        private const int HistoryTop = 135;
        private const int HistoryBottom = 655;
        private const int MaxRowHeight = 64;
        private const int RowPadding = 8;
        private const int NumberWidth = 60;
        private const int PegGap = 8;
        private const int LegendY = 650;
        private const int DebugX = 260;

        private const int RightX = 700;
        private const int RightTitleY = 70;
        private const int CurrentY = 110;
        private const int CurrentSlotSize = 80;
        private const int CurrentSlotGap = 16;
        private const int CursorSize = 36;
        private const int CursorGap = 4;
        private const int PaletteTitleY = 255;
        private const int PaletteY = 295;
        private const int PaletteRowHeight = 54;
        private const int PaletteSlotX = 760;
        private const int PaletteSlotSize = 46;
        private const int PaletteNameGap = 16;
        private const int MessageY = 625;
        private const int MessageWidth = 560;
        private const int HintY = 690;

        private readonly GameSession session;
        private readonly bool showSecret;
        private int cursorSlot;
        private int selectedColor;
        private string message;

        // Inicio constructor PlayingScreen
        public PlayingScreen(GameSession session, bool showSecret)
        {
            this.session = session;
            this.showSecret = showSecret;
            message = "";
        }
        // Fin constructor PlayingScreen

        // Inicio propiedad Session
        public GameSession Session
        {
            get { return session; }
        }
        // Fin propiedad Session

        // Inicio método StartNewGame
        public void StartNewGame(string playerName)
        {
            session.StartNew(playerName);
            cursorSlot = 0;
            selectedColor = 0;
            message = "";
        }
        // Fin método StartNewGame

        // Inicio método Update
        public GameState Update(GameTime gameTime, InputHelper input)
        {
            session.AddTime(gameTime.ElapsedGameTime.TotalSeconds);

            if (input.WasPressed(Keys.Escape))
            {
                return GameState.Menu;
            }

            if (input.WasPressed(Keys.Left) && cursorSlot > 0)
            {
                cursorSlot--;
            }
            if (input.WasPressed(Keys.Right) && cursorSlot < session.CurrentCount && cursorSlot < session.CodeLength - 1)
            {
                cursorSlot++;
            }

            if (input.WasPressed(Keys.Up))
            {
                selectedColor = (selectedColor + Palette.ColorCount - 1) % Palette.ColorCount;
            }
            if (input.WasPressed(Keys.Down))
            {
                selectedColor = (selectedColor + 1) % Palette.ColorCount;
            }

            if (input.WasPressed(Keys.Space))
            {
                PlaceSelectedColor();
            }
            if (input.WasPressed(Keys.Back))
            {
                RemoveLastPeg();
            }
            if (input.WasPressed(Keys.Enter))
            {
                return ConfirmGuess();
            }
            return GameState.Playing;
        }
        // Fin método Update

        // Inicio método PlaceSelectedColor
        private void PlaceSelectedColor()
        {
            bool isNewPeg = cursorSlot == session.CurrentCount;
            if (session.PlaceColor(cursorSlot, (PegColor)selectedColor))
            {
                message = "";
                if (isNewPeg && cursorSlot < session.CodeLength - 1)
                {
                    cursorSlot++;
                }
            }
        }
        // Fin método PlaceSelectedColor

        // Inicio método RemoveLastPeg
        private void RemoveLastPeg()
        {
            if (session.RemoveLast())
            {
                message = "";
                if (cursorSlot > session.CurrentCount)
                {
                    cursorSlot = session.CurrentCount;
                }
            }
            else
            {
                message = "No hay fichas para borrar.";
            }
        }
        // Fin método RemoveLastPeg

        // Inicio método ConfirmGuess
        private GameState ConfirmGuess()
        {
            if (!session.IsGuessComplete())
            {
                message = "Completá las " + session.CodeLength + " posiciones antes de confirmar con Enter.";
                return GameState.Playing;
            }

            Attempt attempt = session.SubmitGuess();
            cursorSlot = 0;
            if (session.IsFinished)
            {
                return GameState.GameOver;
            }
            message = "Intento " + attempt.Number + ": " + attempt.ExactCount + " en su lugar y " + attempt.PresentCount + " en otro lugar. Perdiste una vida.";
            return GameState.Playing;
        }
        // Fin método ConfirmGuess

        // Inicio método GetLivesColor
        private static Color GetLivesColor(int lives, int maxLives)
        {
            if (lives >= maxLives)
            {
                return Renderer.TextColor;
            }
            if (lives <= 1)
            {
                return Renderer.RedColor;
            }
            float ratio = (float)lives / maxLives;
            if (ratio >= GreenRatio)
            {
                return Renderer.GoodColor;
            }
            if (ratio >= YellowRatio)
            {
                return Renderer.HighlightColor;
            }
            return Renderer.OrangeColor;
        }
        // Fin método GetLivesColor

        // Inicio método GetResultColor
        private static Color GetResultColor(int exactCount, int codeLength)
        {
            if (exactCount == 0)
            {
                return Renderer.RedColor;
            }
            float ratio = (float)exactCount / codeLength;
            if (ratio >= GreenRatio)
            {
                return Renderer.GoodColor;
            }
            if (ratio >= YellowRatio)
            {
                return Renderer.HighlightColor;
            }
            return Renderer.OrangeColor;
        }
        // Fin método GetResultColor

        // Inicio método Draw
        public void Draw(Renderer r)
        {
            DrawTopBar(r);
            DrawHistory(r);
            DrawCurrentGuess(r);
            DrawPalette(r);

            string text = message;
            if (session.Warning.Length > 0)
            {
                text = session.Warning;
            }
            if (text.Length > 0)
            {
                r.DrawWrapped(r.SmallFont, text, RightX, MessageY, MessageWidth, 2, Renderer.HighlightColor);
            }
            r.DrawCentered(r.SmallFont, "Izquierda/Derecha: posición · Arriba/Abajo: color · Espacio: poner ficha · Retroceso: borrar · Enter: confirmar · Esc: menú", HintY, Renderer.DimTextColor);
        }
        // Fin método Draw

        // Inicio método DrawTopBar
        private void DrawTopBar(Renderer r)
        {
            r.DrawText(r.RegularFont, "Vidas: " + session.Lives + " / " + session.MaxLives, LivesX, TopBarY, GetLivesColor(session.Lives, session.MaxLives));
            r.DrawText(r.RegularFont, "Puntaje: " + session.PotentialScore(), RightX, TopBarY, Renderer.HighlightColor);

            string time = "Tiempo: " + Renderer.FormatTime(session.SecondsPlayed);
            float timeX = Renderer.ScreenWidth - RightMargin - r.RegularFont.MeasureString(time).X;
            r.DrawText(r.RegularFont, time, timeX, TopBarY, Renderer.TextColor);
        }
        // Fin método DrawTopBar

        // Inicio método DrawHistory
        private void DrawHistory(Renderer r)
        {
            r.DrawText(r.MediumFont, "Historial de intentos", HistoryX, HistoryTitleY, Renderer.DimTextColor);
            if (showSecret)
            {
                string secret = "(prueba) Código:";
                for (int i = 0; i < session.CodeLength; i++)
                {
                    secret += " " + Palette.GetShortName(session.GetSecretAt(i));
                }
                r.DrawText(r.SmallFont, secret, DebugX, HistoryTitleY + 2, Renderer.BadColor);
            }

            int rowHeight = (HistoryBottom - HistoryTop) / session.MaxLives;
            if (rowHeight > MaxRowHeight)
            {
                rowHeight = MaxRowHeight;
            }
            int pegSize = rowHeight - RowPadding;
            int pegsX = HistoryX + NumberWidth;

            for (int row = 0; row < session.MaxLives; row++)
            {
                int y = HistoryTop + row * rowHeight;
                float textY = y + (pegSize - r.MediumFont.LineSpacing) / 2f;
                Attempt attempt = session.History.GetAt(row);

                if (attempt == null)
                {
                    r.DrawText(r.MediumFont, "#" + (row + 1), HistoryX, textY, Renderer.DimTextColor);
                    continue;
                }

                r.DrawText(r.MediumFont, "#" + attempt.Number, HistoryX, textY, GetResultColor(attempt.ExactCount, session.CodeLength));
                for (int i = 0; i < session.CodeLength; i++)
                {
                    Rectangle slot = new Rectangle(pegsX + i * (pegSize + PegGap), y, pegSize, pegSize);
                    r.DrawPegWithBorder(attempt.Pegs[i], attempt.Results[i], slot);
                }
            }

            DrawLegend(r);
        }
        // Fin método DrawHistory

        // Inicio método DrawLegend
        private void DrawLegend(Renderer r)
        {
            string[] parts = { "Verde: lugar correcto", "Amarillo: otro lugar", "Rojo: no está" };
            Color[] colors = { Renderer.ExactBorderColor, Renderer.PresentBorderColor, Renderer.AbsentBorderColor };
            string separator = "  ·  ";

            float x = HistoryX;
            for (int i = 0; i < parts.Length; i++)
            {
                r.DrawText(r.SmallFont, parts[i], x, LegendY, colors[i]);
                x += r.SmallFont.MeasureString(parts[i]).X;
                if (i < parts.Length - 1)
                {
                    r.DrawText(r.SmallFont, separator, x, LegendY, Renderer.DimTextColor);
                    x += r.SmallFont.MeasureString(separator).X;
                }
            }
        }
        // Fin método DrawLegend

        // Inicio método DrawCurrentGuess
        private void DrawCurrentGuess(Renderer r)
        {
            int attemptNumber = session.History.Count() + 1;
            r.DrawText(r.RegularFont, "Intento actual (" + attemptNumber + " de " + session.MaxLives + ")", RightX, RightTitleY, Renderer.DimTextColor);

            for (int i = 0; i < session.CodeLength; i++)
            {
                Rectangle slot = new Rectangle(RightX + i * (CurrentSlotSize + CurrentSlotGap), CurrentY, CurrentSlotSize, CurrentSlotSize);
                if (i < session.CurrentCount)
                {
                    r.DrawPeg(session.GetGuessAt(i), slot);
                }
                else
                {
                    r.DrawEmptySlot(slot);
                }

                if (i == cursorSlot)
                {
                    Rectangle cursor = new Rectangle(slot.X + (slot.Width - CursorSize) / 2, slot.Bottom + CursorGap, CursorSize, CursorSize);
                    r.DrawCursor(cursor, "^");
                }
            }
        }
        // Fin método DrawCurrentGuess

        // Inicio método DrawPalette
        private void DrawPalette(Renderer r)
        {
            r.DrawText(r.RegularFont, "Paleta de colores", RightX, PaletteTitleY, Renderer.DimTextColor);
            for (int i = 0; i < Palette.ColorCount; i++)
            {
                int y = PaletteY + i * PaletteRowHeight;
                PegColor color = (PegColor)i;
                bool selected = i == selectedColor;

                r.DrawPeg(color, new Rectangle(PaletteSlotX, y, PaletteSlotSize, PaletteSlotSize));
                float nameY = y + (PaletteSlotSize - r.RegularFont.LineSpacing) / 2f;
                r.DrawText(r.RegularFont, Palette.GetName(color), PaletteSlotX + PaletteSlotSize + PaletteNameGap, nameY, selected ? Renderer.HighlightColor : Renderer.TextColor);

                if (selected)
                {
                    Rectangle cursor = new Rectangle(RightX + CursorGap, y + (PaletteSlotSize - CursorSize) / 2, CursorSize, CursorSize);
                    r.DrawCursor(cursor, ">");
                }
            }
        }
        // Fin método DrawPalette
    }
    // Fin clase PlayingScreen
}
