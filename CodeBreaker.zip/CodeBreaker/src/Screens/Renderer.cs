using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using CodeBreaker.Data;
using CodeBreaker.Models;

namespace CodeBreaker.Screens
{
    // Inicio clase Renderer
    public class Renderer
    {
        public const int ScreenWidth = 1280;
        public const int ScreenHeight = 720;

        public static readonly Color BackgroundColor = new Color(58, 74, 92);
        public static readonly Color DefeatBackgroundColor = new Color(84, 38, 46);
        public static readonly Color TextColor = Color.White;
        public static readonly Color DimTextColor = new Color(175, 185, 200);
        public static readonly Color HighlightColor = new Color(255, 215, 80);
        public static readonly Color GoodColor = new Color(120, 225, 120);
        public static readonly Color OrangeColor = new Color(255, 160, 60);
        public static readonly Color RedColor = new Color(255, 85, 85);
        public static readonly Color BadColor = new Color(255, 125, 115);

        public static readonly Color ExactBorderColor = new Color(115, 181, 2);
        public static readonly Color PresentBorderColor = new Color(253, 185, 1);
        public static readonly Color AbsentBorderColor = new Color(238, 39, 47);

        private const int BigSlotSize = 60;
        private const int BorderInsetDivisor = 7;

        private readonly SpriteBatch spriteBatch;
        private readonly SpriteAtlas atlas;

        private readonly int[] colorSprites = new int[Palette.ColorCount];
        private int frameExactSprite = SpriteAtlas.NotFound;
        private int framePresentSprite = SpriteAtlas.NotFound;
        private int frameAbsentSprite = SpriteAtlas.NotFound;
        private int cursorSprite = SpriteAtlas.NotFound;
        private int emptySprite = SpriteAtlas.NotFound;

        public SpriteFont TitleFont { get; private set; }
        public SpriteFont RegularFont { get; private set; }
        public SpriteFont MediumFont { get; private set; }
        public SpriteFont SmallFont { get; private set; }
        public string Warning { get; private set; }

        // Inicio constructor Renderer
        public Renderer(SpriteBatch spriteBatch, SpriteAtlas atlas, SpriteFont titleFont, SpriteFont regularFont, SpriteFont mediumFont, SpriteFont smallFont)
        {
            this.spriteBatch = spriteBatch;
            this.atlas = atlas;
            TitleFont = titleFont;
            RegularFont = regularFont;
            MediumFont = mediumFont;
            SmallFont = smallFont;
            Warning = "";
            for (int i = 0; i < Palette.ColorCount; i++)
            {
                colorSprites[i] = SpriteAtlas.NotFound;
            }
        }
        // Fin constructor Renderer

        // Inicio método ResolveSprites
        public void ResolveSprites(GameConfig config)
        {
            string missing = "";
            for (int i = 0; i < Palette.ColorCount; i++)
            {
                colorSprites[i] = FindSprite(config.ColorSprites[i], ref missing);
            }
            frameExactSprite = FindSprite(config.FrameExactSprite, ref missing);
            framePresentSprite = FindSprite(config.FramePresentSprite, ref missing);
            frameAbsentSprite = FindSprite(config.FrameAbsentSprite, ref missing);
            cursorSprite = FindSprite(config.CursorSprite, ref missing);
            emptySprite = FindSprite(config.EmptySprite, ref missing);

            Warning = "";
            if (missing.Length > 0 && atlas.SpriteCount > 0)
            {
                Warning = "Sprites que no se encontraron en Content/Sprites: " + missing + ". Se dibujan letras (revisá config.conf).";
            }
        }
        // Fin método ResolveSprites

        // Inicio método FindSprite
        private int FindSprite(string name, ref string missing)
        {
            int index = atlas.Find(name);
            if (index == SpriteAtlas.NotFound && !string.IsNullOrEmpty(name))
            {
                missing = missing.Length == 0 ? name : missing + ", " + name;
            }
            return index;
        }
        // Fin método FindSprite

        // Inicio método DrawText
        public void DrawText(SpriteFont font, string text, float x, float y, Color color)
        {
            spriteBatch.DrawString(font, text, new Vector2(x, y), color);
        }
        // Fin método DrawText

        // Inicio método DrawCentered
        public void DrawCentered(SpriteFont font, string text, float y, Color color)
        {
            Vector2 size = font.MeasureString(text);
            DrawText(font, text, (ScreenWidth - size.X) / 2f, y, color);
        }
        // Fin método DrawCentered

        // Inicio método DrawTextInBox
        public void DrawTextInBox(SpriteFont font, string text, Rectangle box, Color color)
        {
            Vector2 size = font.MeasureString(text);
            DrawText(font, text, box.X + (box.Width - size.X) / 2f, box.Y + (box.Height - size.Y) / 2f, color);
        }
        // Fin método DrawTextInBox

        // Inicio método DrawWrapped
        public float DrawWrapped(SpriteFont font, string text, float x, float y, float maxWidth, int maxLines, Color color)
        {
            string[] words = text.Split(' ');
            string line = "";
            int lines = 0;
            for (int i = 0; i < words.Length; i++)
            {
                string candidate = line.Length == 0 ? words[i] : line + " " + words[i];
                if (font.MeasureString(candidate).X > maxWidth && line.Length > 0)
                {
                    DrawText(font, line, x, y, color);
                    y += font.LineSpacing;
                    lines++;
                    if (lines == maxLines)
                    {
                        return y;
                    }
                    line = words[i];
                }
                else
                {
                    line = candidate;
                }
            }
            if (line.Length > 0)
            {
                DrawText(font, line, x, y, color);
                y += font.LineSpacing;
            }
            return y;
        }
        // Fin método DrawWrapped

        // Inicio método FormatTime
        public static string FormatTime(int totalSeconds)
        {
            int minutes = totalSeconds / 60;
            int seconds = totalSeconds % 60;
            return minutes.ToString("00") + ":" + seconds.ToString("00");
        }
        // Fin método FormatTime

        // Inicio método DrawPeg
        public void DrawPeg(PegColor color, Rectangle area)
        {
            int sprite = colorSprites[(int)color];
            if (sprite != SpriteAtlas.NotFound)
            {
                atlas.Draw(spriteBatch, sprite, area);
            }
            else
            {
                DrawTextInBox(FontFor(area), Palette.GetShortName(color), area, Palette.GetTextColor(color));
            }
        }
        // Fin método DrawPeg

        // Inicio método DrawEmptySlot
        public void DrawEmptySlot(Rectangle area)
        {
            if (emptySprite != SpriteAtlas.NotFound)
            {
                atlas.Draw(spriteBatch, emptySprite, area);
            }
            else
            {
                DrawTextInBox(FontFor(area), "--", area, DimTextColor);
            }
        }
        // Fin método DrawEmptySlot

        // Inicio método GetBorderColor
        public static Color GetBorderColor(PegResult result)
        {
            switch (result)
            {
                case PegResult.Exact: return ExactBorderColor;
                case PegResult.Present: return PresentBorderColor;
                default: return AbsentBorderColor;
            }
        }
        // Fin método GetBorderColor

        // Inicio método GetFrameSprite
        private int GetFrameSprite(PegResult result)
        {
            switch (result)
            {
                case PegResult.Exact: return frameExactSprite;
                case PegResult.Present: return framePresentSprite;
                default: return frameAbsentSprite;
            }
        }
        // Fin método GetFrameSprite

        // Inicio método DrawPegWithBorder
        public void DrawPegWithBorder(PegColor color, PegResult result, Rectangle area)
        {
            int frame = GetFrameSprite(result);
            if (frame != SpriteAtlas.NotFound)
            {
                atlas.Draw(spriteBatch, frame, area);
            }
            else
            {
                Color borderColor = GetBorderColor(result);
                Vector2 bracketSize = RegularFont.MeasureString("[");
                float bracketY = area.Y + (area.Height - bracketSize.Y) / 2f;
                DrawText(RegularFont, "[", area.X, bracketY, borderColor);
                DrawText(RegularFont, "]", area.Right - bracketSize.X, bracketY, borderColor);
            }

            int inset = area.Width / BorderInsetDivisor;
            DrawPeg(color, new Rectangle(area.X + inset, area.Y + inset, area.Width - 2 * inset, area.Height - 2 * inset));
        }
        // Fin método DrawPegWithBorder

        // Inicio método DrawCursor
        public void DrawCursor(Rectangle area, string fallbackText)
        {
            if (cursorSprite != SpriteAtlas.NotFound)
            {
                atlas.Draw(spriteBatch, cursorSprite, area);
            }
            else
            {
                DrawTextInBox(RegularFont, fallbackText, area, HighlightColor);
            }
        }
        // Fin método DrawCursor

        // Inicio método DrawPegRow
        public void DrawPegRow(PegColor[] pegs, int length, int x, int y, int size, int gap)
        {
            for (int i = 0; i < length; i++)
            {
                DrawPeg(pegs[i], new Rectangle(x + i * (size + gap), y, size, size));
            }
        }
        // Fin método DrawPegRow

        // Inicio método RowWidth
        public static int RowWidth(int length, int size, int gap)
        {
            return length * size + (length - 1) * gap;
        }
        // Fin método RowWidth

        // Inicio método FontFor
        private SpriteFont FontFor(Rectangle area)
        {
            return area.Height >= BigSlotSize ? RegularFont : SmallFont;
        }
        // Fin método FontFor
    }
    // Fin clase Renderer
}
